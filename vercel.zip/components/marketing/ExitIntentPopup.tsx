'use client';

import { useState, useEffect, useRef } from 'react';
import { X, Rocket, Check } from 'lucide-react';
import Link from 'next/link';

const STORAGE_KEY = 'exitIntentPopupShown';
const STORAGE_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

export function ExitIntentPopup() {
  const [isVisible, setIsVisible] = useState(false);
  const hasShownRef = useRef(false);
  const pageLoadTimeRef = useRef<number | null>(null);

  useEffect(() => {
    // Record page load time
    pageLoadTimeRef.current = Date.now();

    // Check if popup was shown recently
    const checkStorage = () => {
      if (typeof window === 'undefined') return false;
      
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) return false;
      
      try {
        const { timestamp } = JSON.parse(stored);
        const now = Date.now();
        // If shown within last 24 hours, don't show again
        if (now - timestamp < STORAGE_EXPIRY_MS) {
          return true;
        }
      } catch {
        // Invalid storage, allow showing
      }
      
      return false;
    };

    // Don't show if already shown recently
    if (checkStorage()) {
      return;
    }

    const showPopup = () => {
      // Only show if user has been on page for at least 3 seconds
      const timeOnPage = pageLoadTimeRef.current ? Date.now() - pageLoadTimeRef.current : 0;
      if (timeOnPage < 3000) {
        return; // Too soon, don't show
      }

      if (!hasShownRef.current) {
        hasShownRef.current = true;
        setIsVisible(true);
        
        // Store in localStorage
        if (typeof window !== 'undefined') {
          localStorage.setItem(STORAGE_KEY, JSON.stringify({
            timestamp: Date.now()
          }));
        }
      }
    };

    const handleMouseLeave = (e: MouseEvent) => {
      // Trigger when mouse leaves the top of the viewport (within 20px for better detection)
      // This indicates user is trying to close the tab/window or navigate away
      if (e.clientY <= 20 && !hasShownRef.current) {
        showPopup();
      }
    };

    // Also listen for mouseout on document for better cross-browser support
    const handleMouseOut = (e: MouseEvent) => {
      // Check if mouse is leaving the document entirely (relatedTarget is null)
      // and mouse is at the top of the viewport
      if (!e.relatedTarget && e.clientY <= 20 && !hasShownRef.current) {
        showPopup();
      }
    };

    // Add event listeners after a short delay to ensure page is loaded
    const timeoutId = setTimeout(() => {
      document.addEventListener('mouseleave', handleMouseLeave, { passive: true });
      document.addEventListener('mouseout', handleMouseOut, { passive: true });
    }, 1000);

    return () => {
      clearTimeout(timeoutId);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseout', handleMouseOut);
    };
  }, []);

  const handleClose = () => {
    setIsVisible(false);
  };

  // Handle ESC key
  useEffect(() => {
    if (!isVisible) return;

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleClose();
      }
    };

    window.addEventListener('keydown', handleEscape);
    return () => {
      window.removeEventListener('keydown', handleEscape);
    };
  }, [isVisible]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity duration-200 opacity-100"
        onClick={handleClose}
      />
      
      {/* Modal */}
      <div className="relative w-full max-w-lg rounded-2xl border border-white/20 bg-gradient-to-br from-slate-900 to-slate-800 p-8 shadow-2xl transform transition-all duration-200 scale-100 opacity-100">
        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 rounded-lg hover:bg-white/10 transition-colors text-white/60 hover:text-white"
          aria-label="Close"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Content */}
        <div className="text-center">
          {/* Icon */}
          <div className="flex justify-center mb-4">
            <div className="rounded-full bg-red-500/20 p-3 border border-red-500/30">
              <Rocket className="h-8 w-8 text-red-400" />
            </div>
          </div>

          {/* Headline */}
          <h2 className="text-3xl font-bold text-white mb-4">
            Lock in early bird pricing forever
          </h2>

          {/* Subheadline */}
          <p className="text-lg text-white/80 mb-6">
            Founding Member pricing: Lock in $79 (Starter) or $179 (Pro) per month forever. 
            Standard pricing is $149 and $299 respectively. Offer expires March 1, 2026.
          </p>

          {/* Benefits */}
          <div className="text-left mb-8 space-y-3">
            <p className="text-base font-semibold text-white mb-3">
              Early bird benefits:
            </p>
            <div className="space-y-2">
              {[
                'Lifetime price lock at early bird rates',
                '7-day free trial, $0 due today',
                'Cancel anytime with one click'
              ].map((benefit, index) => (
                <div key={index} className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span className="text-white/90">{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="space-y-3">
            <Link
              href="/pricing"
              onClick={handleClose}
              className="inline-block w-full px-8 py-4 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 text-base font-semibold text-white hover:from-emerald-400 hover:to-emerald-500 transition-all shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/40 hover:scale-105"
            >
              View Pricing & Sign Up
            </Link>
            <Link
              href="/pricing"
              onClick={handleClose}
              className="inline-block w-full px-8 py-4 rounded-lg border-2 border-white/20 bg-white/5 text-base font-semibold text-white hover:bg-white/10 hover:border-white/30 transition-all"
            >
              View Pricing
            </Link>
          </div>

          {/* Dismiss link */}
          <button
            onClick={handleClose}
            className="mt-4 text-sm text-white/60 hover:text-white/80 transition-colors"
          >
            No thanks, I'll pass
          </button>
        </div>
      </div>
    </div>
  );
}
