'use client';

import type { Deal } from '@/lib/types/deal';
import { AsyncButton } from '@/components/ui/AsyncButton';

interface StickyDealHeaderProps {
  deal: Deal;
  onProceed: () => void;
  onPark: () => void;
  onPass: () => void;
  settingVerdict: boolean;
}

export function StickyDealHeader({
  deal,
  onProceed,
  onPark,
  onPass,
  settingVerdict,
}: StickyDealHeaderProps) {
  const companyName = deal.company_name || 'Untitled Company';
  const location = [
    deal.location_city,
    deal.location_state
  ].filter(Boolean).join(', ') || 'Location not specified';
  const industry = deal.industry || 'Industry not specified';

  // Extract user-set verdict
  const userVerdict = (deal as any).verdict || deal.criteria_match_json?.verdict || null;
  
  const verdictConfig = {
    proceed: { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/50', label: 'Proceed' },
    park: { bg: 'bg-blue-500/20', text: 'text-blue-300', border: 'border-blue-500/50', label: 'Parked' },
    pass: { bg: 'bg-slate-600/50', text: 'text-slate-300', border: 'border-slate-500', label: 'Passed' }
  };
  
  const userVerdictNormalized = userVerdict ? userVerdict.toLowerCase() : null;
  const userVerdictStyle = userVerdictNormalized ? verdictConfig[userVerdictNormalized as keyof typeof verdictConfig] : null;

  return (
    <div className="sticky top-0 z-40 bg-slate-900 border-b border-slate-700 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <div className="flex items-center gap-6 min-w-0">
          {/* Title: takes remaining space, truncates so it never overlaps buttons */}
          <div className="flex-1 min-w-0 overflow-hidden">
            <h1 className="text-xl sm:text-2xl font-semibold text-slate-50 truncate">
              {companyName}
            </h1>
            <p className="text-sm text-slate-400 truncate">
              {industry} · {location}
            </p>
          </div>
          {/* Verdict + buttons: never shrink, fixed space */}
          <div className="flex items-center gap-4 flex-shrink-0">
          {userVerdictStyle && (
            <div className="hidden sm:flex items-center gap-2">
              <span className={`px-3 py-1.5 rounded-md text-sm font-semibold border ${userVerdictStyle.bg} ${userVerdictStyle.text} ${userVerdictStyle.border}`}>
                {userVerdictStyle.label}
              </span>
            </div>
          )}
          
          <div className="flex items-center gap-2">
            <AsyncButton
              onClick={onProceed}
              isLoading={settingVerdict}
              loadingText="Setting…"
              className={`px-4 py-2 rounded-lg font-medium text-sm border-2 transition-all whitespace-nowrap ${
                userVerdict === 'proceed'
                  ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300'
                  : 'border-slate-600 bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              ✓ Proceed
            </AsyncButton>
            <AsyncButton
              onClick={onPark}
              isLoading={settingVerdict}
              loadingText="Setting…"
              className={`px-4 py-2 rounded-lg font-medium text-sm border-2 transition-all whitespace-nowrap ${
                userVerdict === 'park'
                  ? 'border-blue-500 bg-blue-500/20 text-blue-300'
                  : 'border-slate-600 bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              ⏸ Park
            </AsyncButton>
            <AsyncButton
              onClick={onPass}
              isLoading={settingVerdict}
              className={`px-4 py-2 rounded-lg font-medium text-sm border-2 transition-all whitespace-nowrap ${
                userVerdict === 'pass'
                  ? 'border-slate-500 bg-slate-600/50 text-slate-300'
                  : 'border-slate-600 bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              ✕ Pass
            </AsyncButton>
          </div>
          </div>
        </div>
      </div>
    </div>
  );
}
