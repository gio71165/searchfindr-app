import { NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const tier = url.searchParams.get("tier");
  const plan = url.searchParams.get("plan");
  const billing = url.searchParams.get("billing");

  if (!code) return NextResponse.redirect(new URL("/login?error=missing_code", url.origin));

  const cookieStore = await cookies();

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options);
          });
        },
      },
    }
  );

  const { error } = await supabase.auth.exchangeCodeForSession(code);

  if (error) {
    // Don't expose error details in URL - security risk
    // Log error server-side for debugging
    const { logger } = await import("@/lib/utils/logger");
    logger.error("Auth callback error", { error: error.message });
    return NextResponse.redirect(new URL("/login?error=auth_failed", url.origin));
  }

  // If subscription params exist, redirect to checkout route
  if (tier && plan && billing) {
    return NextResponse.redirect(new URL(`/checkout?tier=${tier}&plan=${plan}&billing=${billing}`, url.origin));
  }

  return NextResponse.redirect(new URL("/dashboard", url.origin));
}
