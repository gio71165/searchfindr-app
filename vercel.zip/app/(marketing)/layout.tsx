import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { MarketingNavigation } from '@/components/marketing/Navigation';
import { Footer } from '@/components/marketing/Footer';
import { ExitIntentPopup } from '@/components/marketing/ExitIntentPopup';
import '../globals.css';

export const metadata: Metadata = {
  title: {
    default: 'SearchFindr - AI Deal Screening for Search Funds',
    template: '%s | SearchFindr'
  },
  description: 'Find better deals faster. AI-powered deal screening for search fund operators. Analyze CIMs, track deals, and make faster acquisition decisions. Get instant red flags, deal tier, and verdict in 60 seconds.',
  keywords: [
    'search fund',
    'deal screening',
    'CIM analysis',
    'AI deal analysis',
    'M&A software',
    'search fund software',
    'confidential information memorandum',
    'deal pipeline management',
    'SBA 7a loan calculator',
    'quality of earnings',
    'red flags analysis',
    'search fund operator',
    'ETA buyer',
    'lower middle market',
    'broker deal tracking',
    'financial analysis',
    'deal memo generator'
  ],
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://searchfindr-app.vercel.app',
    siteName: 'SearchFindr',
    title: 'SearchFindr - AI Deal Screening for Search Funds',
    description: 'Find better deals faster. AI-powered deal screening for search fund operators. Analyze CIMs, track deals, and make faster acquisition decisions.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'SearchFindr - AI Deal Screening for Search Funds',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SearchFindr - AI Deal Screening for Search Funds',
    description: 'Find better deals faster. AI-powered deal screening for search fund operators.',
    images: ['/og-image.png'],
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default async function MarketingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Check if user is authenticated - redirect to dashboard if so
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  
  if (user) {
    redirect('/dashboard');
  }

  return (
    <div className="min-h-screen bg-[#0a0e14] text-white flex flex-col">
      {/* Skip to content link - only visible on keyboard focus */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-emerald-600 focus:text-white focus:rounded-lg focus:shadow-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2"
      >
        Skip to main content
      </a>
      {/* Subtle background gradients */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 left-1/2 h-96 w-[44rem] -translate-x-1/2 rounded-full bg-emerald-500/10 blur-3xl" />
        <div className="absolute -bottom-32 right-1/3 h-96 w-[44rem] rounded-full bg-cyan-500/5 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.03)_1px,transparent_0)] [background-size:32px_32px] opacity-40" />
      </div>

      <MarketingNavigation />
      <main id="main-content" className="flex-1 relative z-10">
        {children}
      </main>
      <Footer />
      <ExitIntentPopup />
    </div>
  );
}
