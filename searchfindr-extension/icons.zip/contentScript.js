console.log("[SearchFindr] content script injected on", location.href);

(function () {
  const TOKEN_KEY = "searchfindr_auth_token";
  const SESSION_STORAGE = chrome.storage.session;
  let tokenSaved = false;

  // Token encoding (same as popup.js)
  function encodeToken(token) {
    return btoa(token + "::" + Date.now());
  }

  function saveToken(token) {
    return new Promise((resolve, reject) => {
      // Validate token
      if (!token || typeof token !== "string" || token.trim().length < 10) {
        reject(new Error("Invalid token"));
        return;
      }

      const encoded = encodeToken(token.trim());
      
      SESSION_STORAGE.set({ [TOKEN_KEY]: encoded }, () => {
        const err = chrome.runtime.lastError;
        if (err) {
          console.error("[SearchFindr] Failed saving token:", err);
          reject(err);
          return;
        }
        tokenSaved = true;
        console.log("[SearchFindr] Token saved successfully");
        
        // Cleanup old storage keys
        chrome.storage.local.remove(["sf_access_token", "searchfindr_auth_token"], () => {});
        chrome.storage.sync.remove(["sf_access_token", "sf_refresh_token", "searchfindr_auth_token"], () => {});
        
        resolve();
      });
    });
  }

  function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Try to read token from data attribute (primary method)
  async function readTokenFromPage(maxRetries = 8, delayMs = 250) {
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      if (tokenSaved) return true;

      const token = document.documentElement.getAttribute('data-searchfindr-token');
      if (token && token.trim().length >= 10) {
        try {
          await saveToken(token.trim());
          return true;
        } catch (e) {
          console.error(`[SearchFindr] Save attempt ${attempt + 1} failed:`, e);
          if (attempt >= maxRetries - 1) return false;
        }
      }

      if (attempt < maxRetries - 1) {
        await delay(delayMs);
      }
    }
    return false;
  }

  // Listen for postMessage (backup method)
  window.addEventListener('message', async (event) => {
    if (event.origin !== window.location.origin) return;
    if (tokenSaved) return;
    
    if (event.data?.type === 'SEARCHFINDR_EXTENSION_TOKEN' && event.data.token) {
      try {
        await saveToken(event.data.token.trim());
      } catch (e) {
        console.error("[SearchFindr] Failed to save token from postMessage:", e);
      }
    }
  });

  // Main execution
  (async () => {
    try {
      // Wait for DOM to be ready
      if (document.readyState === 'loading') {
        await new Promise(resolve => document.addEventListener('DOMContentLoaded', resolve));
      }
      
      // Start reading token immediately (callback page injects it when DOM is ready)
      // The retry loop handles any timing edge cases
      const success = await readTokenFromPage();
      if (!success && !tokenSaved) {
        console.warn("[SearchFindr] Token not found. User may need to log in again.");
      }
    } catch (e) {
      console.error("[SearchFindr] Content script error:", e);
    }
  })();
})();
